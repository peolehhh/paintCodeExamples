//
//  ViewController.h
//  VariablesBasics
//
//  Created by Matej Duník on 5/6/14.
//  Copyright (c) 2014 Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
