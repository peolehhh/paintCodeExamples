//
//  ButtonView.m
//  VariablesBasics
//
//  Created by Matej Duník on 5/6/14.
//  Copyright (c) 2014 Company. All rights reserved.
//

#import "ButtonView.h"

#import "MyStyleKit.h"

@interface ButtonView ()
@property BOOL isPressed;
@property(copy) NSString* title;

@end

@implementation ButtonView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.title = @"Rate!";
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    [MyStyleKit drawRateButtonWithRadius: 10 title: self.title pressed: self.isPressed];
    // Drawing code
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    self.isPressed = YES;
    [self setNeedsDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    self.isPressed = NO;
    self.title = @"Thanks!";
    [self setNeedsDisplay];
}

@end
