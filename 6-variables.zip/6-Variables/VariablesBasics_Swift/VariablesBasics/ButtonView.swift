//
//  ButtonView.swift
//  VariablesBasics
//
//  Created by Matej Dunik on 05/01/15.
//  Copyright (c) 2015 company. All rights reserved.
//

import UIKit

class ButtonView: UIView {

    var isPressed = false
    var title = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.title = "Rate!"
    }
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        MyStyleKit.drawRateButton(radius: 10, title: self.title, pressed: self.isPressed)
        
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        self.isPressed = true
        self.setNeedsDisplay()
    }
    
    override func touchesEnded(touches: NSSet, withEvent event: UIEvent) {
        self.isPressed = false
        self.title = "Thanks!"
        self.setNeedsDisplay()
    }
    
}
