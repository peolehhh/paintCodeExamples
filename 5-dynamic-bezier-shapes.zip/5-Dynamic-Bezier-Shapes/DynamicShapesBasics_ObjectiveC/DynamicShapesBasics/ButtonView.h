//
//  ButtonView.h
//  DynamicShapesBasics
//
//  Created by Peter Krajčík on 4/28/14.
//  Copyright (c) 2014 PixelCut. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonView : UIView

@end
