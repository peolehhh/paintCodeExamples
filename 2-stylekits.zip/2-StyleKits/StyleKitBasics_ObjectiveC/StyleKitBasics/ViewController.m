//
//  ViewController.m
//  StyleKitBasics
//
//  Created by Matej Duník on 5/6/14.
//  Copyright (c) 2014 Company. All rights reserved.
//

#import "ViewController.h"

#import "MyStyleKit.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.label.textColor = [MyStyleKit iconColor];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
