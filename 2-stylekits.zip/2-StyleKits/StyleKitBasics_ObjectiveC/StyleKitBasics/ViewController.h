//
//  ViewController.h
//  StyleKitBasics
//
//  Created by Matej Duník on 5/6/14.
//  Copyright (c) 2014 Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
